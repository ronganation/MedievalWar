[CmdletBinding()]
param([string]$ProjectRoot = "C:\UnrealProjects\MedievalWar")
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$Target = Join-Path $ProjectRoot "Plugins\MWSharedImporter\Source\MWSharedImporter\Private\Tests\MWNorwayOpeningStatePreviewDispositionTests.cpp"
if (-not (Test-Path -LiteralPath $Target -PathType Leaf)) { throw "Repair test file not found: $Target" }
$Text = Get-Content -LiteralPath $Target -Raw
$Old = 'FMWNorwayOpeningStatePreviewPresentation::BuildFromRegisteredProvider()'
$New = 'FMWNorwayOpeningStatePreviewPresentation::CaptureRegisteredProvider()'
$Count = ([regex]::Matches($Text,[regex]::Escape($Old))).Count
if ($Count -ne 2) { throw "Expected exactly two obsolete calls; found $Count" }
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Rollback = Join-Path $Root "Rollback_OS_VIS_03H_Compile_Hotfix_01_$Timestamp"
$Evidence = Join-Path $Root "Evidence_OS_VIS_03H_Compile_Hotfix_01_$Timestamp"
New-Item -ItemType Directory -Force -Path $Rollback,$Evidence | Out-Null
$Backup = Join-Path $Rollback "MWNorwayOpeningStatePreviewDispositionTests.cpp"
Copy-Item -LiteralPath $Target -Destination $Backup -Force
$Pre = (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash
$Text = $Text.Replace($Old,$New)
Set-Content -LiteralPath $Target -Value $Text -Encoding UTF8
$Post = (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash
[ordered]@{TaskId='OS-VIS-03H-COMPILE-HOTFIX-01';Target=$Target;Backup=$Backup;PreChangeSHA256=$Pre;PostChangeSHA256=$Post;Correction='Replace nonexistent BuildFromRegisteredProvider with existing CaptureRegisteredProvider';ChangedOccurrences=2;GameInstanceCreated=$false;ApplyCalled=$false;SaveWritten=$false;RegistryMutated=$false;RealmPayloadApplied=$false;TheaterActivated=$false}|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $Evidence 'OS_VIS_03H_Compile_Hotfix_01_Manifest.json') -Encoding UTF8
Write-Host 'OS-VIS-03H compile hotfix 01 installed.' -ForegroundColor Green
Write-Host "Rollback: $Rollback"
Write-Host "Evidence: $Evidence"
Write-Host 'Changed occurrences: 2'
