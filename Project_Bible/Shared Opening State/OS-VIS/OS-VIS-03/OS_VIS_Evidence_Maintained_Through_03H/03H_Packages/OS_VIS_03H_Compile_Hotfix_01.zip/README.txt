OS-VIS-03H Compile Hotfix 01

The additive test called a nonexistent method named BuildFromRegisteredProvider. The verified presentation API declares CaptureRegisteredProvider(). This hotfix replaces exactly two calls in MWNorwayOpeningStatePreviewDispositionTests.cpp and records rollback plus hashes.

Run with Unreal Editor closed:

Set-ExecutionPolicy -Scope Process Bypass
.\Install_OS_VIS_03H_Compile_Hotfix_01.ps1

Then build directly:

& "C:\Program Files\Epic Games\UE_5.8\Engine\Build\BatchFiles\Build.bat" MedievalWarEditor Win64 Development -Project="C:\UnrealProjects\MedievalWar\MedievalWar.uproject" -WaitMutex -NoHotReloadFromIDE -NoUBTMakefiles
