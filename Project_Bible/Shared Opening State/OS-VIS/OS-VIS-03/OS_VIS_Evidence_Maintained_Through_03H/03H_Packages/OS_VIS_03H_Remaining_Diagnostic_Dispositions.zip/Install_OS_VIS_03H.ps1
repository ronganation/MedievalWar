[CmdletBinding()]
param([string]$ProjectRoot = "C:\UnrealProjects\MedievalWar")
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProjectFile = Join-Path $ProjectRoot "MedievalWar.uproject"
if (-not (Test-Path -LiteralPath $ProjectFile -PathType Leaf)) { throw "Project file not found: $ProjectFile" }
$Presentation = Join-Path $ProjectRoot "Plugins\MWSharedImporter\Source\MWSharedImporter\Private\MWNorwayOpeningStatePreviewPresentation.cpp"
$Tests = Join-Path $ProjectRoot "Plugins\MWSharedImporter\Source\MWSharedImporter\Private\Tests\MWNorwayOpeningStatePreviewPresentationTests.cpp"
$Targets = @($Presentation,$Tests)
foreach ($Target in $Targets) { if (-not (Test-Path -LiteralPath $Target -PathType Leaf)) { throw "Required file not found: $Target" } }
$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Evidence = Join-Path $Root "Evidence_OS_VIS_03H_$Timestamp"
$Rollback = Join-Path $Root "Rollback_OS_VIS_03H_$Timestamp"
New-Item -ItemType Directory -Force -Path $Evidence,$Rollback | Out-Null
$Manifest = @()
foreach ($Target in $Targets) {
  $Relative = $Target.Substring($ProjectRoot.Length).TrimStart('\')
  $Backup = Join-Path $Rollback $Relative
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Backup) | Out-Null
  Copy-Item -LiteralPath $Target -Destination $Backup -Force
  $Manifest += [ordered]@{RelativePath=$Relative;TargetPath=$Target;BackupPath=$Backup;PreChangeSHA256=(Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash}
}
function Replace-ExactlyOnce([string]$Text,[string]$Old,[string]$New,[string]$Label) {
  $Count = ([regex]::Matches($Text,[regex]::Escape($Old))).Count
  if ($Count -ne 1) { throw "$Label expected exactly one match; found $Count" }
  return $Text.Replace($Old,$New)
}
$P = Get-Content -LiteralPath $Presentation -Raw
$P = Replace-ExactlyOnce $P '    View.UnknownRecords = Unavailable;' '    View.UnknownRecords = TEXT("Blocked: no explicit Norway per-record Unknown disposition contract is exposed by the current candidate API; count not inferred");' 'Unknown disposition'
$P = Replace-ExactlyOnce $P '    View.IntentionalEmptyRecords = Unavailable;' '    View.IntentionalEmptyRecords = TEXT("Blocked: no explicit Norway IntentionalEmpty marker is exposed by the current candidate API; zero payload counts are not treated as IntentionalEmpty");' 'IntentionalEmpty disposition'
$P = Replace-ExactlyOnce $P '    View.ExternalLocks = Unavailable;' '    View.ExternalLocks = TEXT("Authority-only pending candidate-bound read-only API; no ExternalLock count or activation state inferred");' 'ExternalLock disposition'
$P = Replace-ExactlyOnce $P '    View.AssetAndMapBindingBlockers = Unavailable;' '    View.AssetAndMapBindingBlockers = TEXT("Pending active Unreal asset/map scan or verified binding report; authority prose and .uasset/.umap presence are not runtime validation");' 'Asset map disposition'
$P = Replace-ExactlyOnce $P '    View.ActiveUnitInventoryDisposition = Unavailable;' '    View.ActiveUnitInventoryDisposition = TEXT("AuthorityMappedPendingActiveUnrealAssetScan; active definitions and runtime instances are not validated");' 'Unit inventory disposition'
Set-Content -LiteralPath $Presentation -Value $P -Encoding UTF8
$T = Get-Content -LiteralPath $Tests -Raw
$Needle = '    TestEqual(TEXT("IntentionalEmpty unavailable rather than treated as missing"), First.IntentionalEmptyRecords, FString(TEXT("Unavailable from verified read-only API")));'
$Replacement = @'
    TestTrue(TEXT("Unknown remains blocked without inferred count"), First.UnknownRecords.Contains(TEXT("count not inferred")));
    TestTrue(TEXT("IntentionalEmpty requires explicit Norway marker"), First.IntentionalEmptyRecords.Contains(TEXT("no explicit Norway IntentionalEmpty marker")));
    TestTrue(TEXT("Zero payload counts are not IntentionalEmpty"), First.IntentionalEmptyRecords.Contains(TEXT("zero payload counts are not treated as IntentionalEmpty")));
    TestTrue(TEXT("ExternalLocks remain authority-only"), First.ExternalLocks.Contains(TEXT("Authority-only")));
    TestTrue(TEXT("ExternalLock count is not inferred"), First.ExternalLocks.Contains(TEXT("no ExternalLock count")));
    TestTrue(TEXT("Asset and map bindings require active scan or report"), First.AssetAndMapBindingBlockers.Contains(TEXT("active Unreal asset/map scan")));
    TestTrue(TEXT("Unit inventory remains pending active scan"), First.ActiveUnitInventoryDisposition.Contains(TEXT("AuthorityMappedPendingActiveUnrealAssetScan")));
    TestTrue(TEXT("Runtime instances are not validated"), First.ActiveUnitInventoryDisposition.Contains(TEXT("runtime instances are not validated")));
'@
$T = Replace-ExactlyOnce $T $Needle $Replacement '03H presentation assertions'
Set-Content -LiteralPath $Tests -Value $T -Encoding UTF8
for ($i=0;$i -lt $Manifest.Count;$i++){$Manifest[$i].PostChangeSHA256=(Get-FileHash -LiteralPath $Manifest[$i].TargetPath -Algorithm SHA256).Hash}
$Receipt=[ordered]@{TaskId='OS-VIS-03H';Title='Remaining Diagnostic Disposition Presentation';InstalledUtc=(Get-Date).ToUniversalTime().ToString('o');ChangedFileCount=2;Files=$Manifest;SourceAudit='OS_VIS_03G_Remaining_Diagnostics_Audit.json';UnknownExposure='Blocked_NoPerRecordContract';IntentionalEmptyExposure='Blocked_NoExplicitMarker';ExternalLocksExposure='AuthorityOnlyPendingCandidateAPI';AssetMapBindingsExposure='PendingActiveScanOrBindingReport';UnitInventoryExposure='AuthorityMappedPendingActiveUnrealAssetScan';GameInstanceCreated=$false;CanApplyCalled=$false;ApplyCalled=$false;OwnerInvoked=$false;TransactionExecuted=$false;SaveWritten=$false;RegistryMutated=$false;RealmPayloadApplied=$false;TheaterActivated=$false}
$Receipt|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $Evidence 'OS_VIS_03H_File_Manifest.json') -Encoding UTF8
Write-Host 'OS-VIS-03H remaining diagnostic dispositions installed.' -ForegroundColor Green
Write-Host "Evidence: $Evidence"
Write-Host "Rollback: $Rollback"
Write-Host 'Changed files: 2'
Write-Host 'No diagnostic count or activation state was inferred.'
Write-Host 'No GameInstance, application, owner invocation, transaction, save, Registry, Realm, Theater, or world-state action was performed.'
