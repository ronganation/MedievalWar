# OS-VIS-03H Remaining Diagnostic Disposition Presentation

This two-file batch converts the final five vague `Unavailable` rows into exact evidence-based dispositions from OS-VIS-03G. It does not claim counts, activation, bindings, or runtime assets that the current Norway candidate API cannot prove.

## Install

Close Unreal Editor, then run:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Install_OS_VIS_03H.ps1
```

## Build

Run the validated reusable build script.

## Tests

Run separately:

- `MedievalWar.OpeningState.Preview`
- `MedievalWar.SharedImporter.Norway.Translation.DryRunNoMutation`
- `MedievalWar.SharedImporter.Norway`

## Visual acceptance

Confirm the final five rows now explain why exposure is blocked or pending, while all Campaign, save, Registry, Realm, and Theater boundaries remain closed.
