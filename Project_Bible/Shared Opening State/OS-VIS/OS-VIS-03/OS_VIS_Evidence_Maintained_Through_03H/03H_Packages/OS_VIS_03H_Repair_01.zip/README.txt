OS-VIS-03H Repair 01

The first 03H installer updated the five presentation strings, then stopped because an obsolete exact test line no longer existed after OS-VIS-03F.

This repair:
- verifies all five 03H presentation strings are already present;
- does not rewrite the existing presentation file;
- does not touch the existing presentation test file;
- adds one independent automation test file;
- creates a repair manifest.

Run with Unreal Editor closed:

Set-ExecutionPolicy -Scope Process Bypass
.\Repair_OS_VIS_03H.ps1

Then run the reusable build script. The preview parent will gain one additional test:

MedievalWar.OpeningState.Preview.Norway.Presentation.RemainingDiagnosticDispositions

Expected preview-parent total: 8 tests, unless other tests have been added locally. Preserve the observed count.
