[CmdletBinding()]
param([string]$ProjectRoot = "C:\UnrealProjects\MedievalWar")

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$ProjectFile = Join-Path $ProjectRoot "MedievalWar.uproject"
$Presentation = Join-Path $ProjectRoot "Plugins\MWSharedImporter\Source\MWSharedImporter\Private\MWNorwayOpeningStatePreviewPresentation.cpp"
$TestFile = Join-Path $ProjectRoot "Plugins\MWSharedImporter\Source\MWSharedImporter\Private\Tests\MWNorwayOpeningStatePreviewDispositionTests.cpp"

if (-not (Test-Path -LiteralPath $ProjectFile -PathType Leaf)) { throw "Project file not found: $ProjectFile" }
if (-not (Test-Path -LiteralPath $Presentation -PathType Leaf)) { throw "Presentation file not found: $Presentation" }

$ExpectedPresentationStrings = @(
    'count not inferred',
    'zero payload counts are not treated as IntentionalEmpty',
    'no ExternalLock count or activation state inferred',
    'active Unreal asset/map scan or verified binding report',
    'AuthorityMappedPendingActiveUnrealAssetScan'
)

$PresentationText = Get-Content -LiteralPath $Presentation -Raw
$MissingStrings = @($ExpectedPresentationStrings | Where-Object { $PresentationText.IndexOf($_, [System.StringComparison]::Ordinal) -lt 0 })
if ($MissingStrings.Count -gt 0) {
    throw "The partial 03H presentation update is not complete. Missing: $($MissingStrings -join '; ')"
}

if (Test-Path -LiteralPath $TestFile -PathType Leaf) {
    throw "Repair target already exists: $TestFile"
}

$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Evidence = Join-Path $Root "Evidence_OS_VIS_03H_Repair_$Timestamp"
New-Item -ItemType Directory -Force -Path $Evidence | Out-Null

$TestSource = @'
#include "MWNorwayOpeningStatePreviewPresentation.h"

#if WITH_DEV_AUTOMATION_TESTS

#include "Misc/AutomationTest.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(
    FMWNorwayOpeningStatePreviewDispositionTest,
    "MedievalWar.OpeningState.Preview.Norway.Presentation.RemainingDiagnosticDispositions",
    EAutomationTestFlags::EditorContext |
    EAutomationTestFlags::EngineFilter)

bool FMWNorwayOpeningStatePreviewDispositionTest::RunTest(
    const FString& Parameters)
{
    const FMWNorwayOpeningStatePreviewPresentation View =
        FMWNorwayOpeningStatePreviewPresentation::BuildFromRegisteredProvider();

    TestTrue(
        TEXT("Unknown remains blocked without inferred count"),
        View.UnknownRecords.Contains(TEXT("count not inferred")));

    TestTrue(
        TEXT("IntentionalEmpty requires explicit Norway marker"),
        View.IntentionalEmptyRecords.Contains(
            TEXT("no explicit Norway IntentionalEmpty marker")));

    TestTrue(
        TEXT("Zero payload counts are not IntentionalEmpty"),
        View.IntentionalEmptyRecords.Contains(
            TEXT("zero payload counts are not treated as IntentionalEmpty")));

    TestTrue(
        TEXT("ExternalLock count and activation are not inferred"),
        View.ExternalLocks.Contains(
            TEXT("no ExternalLock count or activation state inferred")));

    TestTrue(
        TEXT("Asset and map bindings require active scan or report"),
        View.AssetAndMapBindingBlockers.Contains(
            TEXT("active Unreal asset/map scan or verified binding report")));

    TestTrue(
        TEXT("Unit inventory remains pending active scan"),
        View.ActiveUnitInventoryDisposition.Contains(
            TEXT("AuthorityMappedPendingActiveUnrealAssetScan")));

    TestTrue(
        TEXT("Active unit definitions and runtime instances are not validated"),
        View.ActiveUnitInventoryDisposition.Contains(
            TEXT("active definitions and runtime instances are not validated")));

    const FMWNorwayOpeningStatePreviewPresentation RepeatedView =
        FMWNorwayOpeningStatePreviewPresentation::BuildFromRegisteredProvider();

    TestEqual(
        TEXT("Remaining diagnostic presentation is deterministic"),
        RepeatedView.BuildDeterministicSummary(),
        View.BuildDeterministicSummary());

    return !HasAnyErrors();
}

#endif
'@

New-Item -ItemType Directory -Force -Path (Split-Path -Parent $TestFile) | Out-Null
Set-Content -LiteralPath $TestFile -Value $TestSource -Encoding UTF8

$Manifest = [ordered]@{
    TaskId = 'OS-VIS-03H-REPAIR-01'
    Title = 'Finalize partial 03H installation with additive automation coverage'
    InstalledUtc = (Get-Date).ToUniversalTime().ToString('o')
    ProjectRoot = $ProjectRoot
    PresentationAlreadyUpdatedByFirstAttempt = $true
    PresentationPath = $Presentation
    PresentationSHA256 = (Get-FileHash -LiteralPath $Presentation -Algorithm SHA256).Hash
    AdditiveTestPath = $TestFile
    AdditiveTestSHA256 = (Get-FileHash -LiteralPath $TestFile -Algorithm SHA256).Hash
    ExistingTestFileModified = $false
    Rollback = "Delete additive test file; use original 03H rollback folder only if presentation rollback is required"
    SourceFilesAdded = 1
    SourceFilesModifiedByRepair = 0
    GameInstanceCreated = $false
    CanApplyCalled = $false
    ApplyCalled = $false
    OwnerInvoked = $false
    TransactionExecuted = $false
    SaveWritten = $false
    RegistryMutated = $false
    RealmPayloadApplied = $false
    TheaterActivated = $false
}
$Manifest | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $Evidence 'OS_VIS_03H_Repair_Manifest.json') -Encoding UTF8

Write-Host 'OS-VIS-03H repair completed.' -ForegroundColor Green
Write-Host 'The five presentation changes from the first attempt were verified.'
Write-Host "Added test: $TestFile"
Write-Host "Evidence: $Evidence"
Write-Host 'Existing test source was not edited.'
Write-Host 'No GameInstance, application, owner invocation, transaction, save, Registry, Realm, Theater, or world-state action was performed.'
