[CmdletBinding()]
param([string]$ProjectRoot = "C:\UnrealProjects\MedievalWar")

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$Target = Join-Path $ProjectRoot "Plugins\MWSharedImporter\Source\MWSharedImporter\Private\Tests\MWNorwayOpeningStatePreviewPresentationTests.cpp"
if (-not (Test-Path -LiteralPath $Target -PathType Leaf)) { throw "Test file not found: $Target" }

$Text = Get-Content -LiteralPath $Target -Raw
$UnknownPattern = '(?m)^\s*TestEqual\(TEXT\("Unknown records unavailable rather than zero"\),\s*First\.UnknownRecords,\s*FString\(TEXT\("Unavailable from verified read-only API"\)\)\);\s*$'
$IntentionalPattern = '(?m)^\s*TestEqual\(TEXT\("IntentionalEmpty unavailable rather than missing"\),\s*First\.IntentionalEmptyRecords,\s*FString\(TEXT\("Unavailable from verified read-only API"\)\)\);\s*$'

$UnknownCount = ([regex]::Matches($Text, $UnknownPattern)).Count
$IntentionalCount = ([regex]::Matches($Text, $IntentionalPattern)).Count
if ($UnknownCount -ne 1) { throw "Expected one stale Unknown assertion; found $UnknownCount" }
if ($IntentionalCount -ne 1) { throw "Expected one stale IntentionalEmpty assertion; found $IntentionalCount" }

$Timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Rollback = Join-Path $Root "Rollback_OS_VIS_03H_Test_Hotfix_01_$Timestamp"
$Evidence = Join-Path $Root "Evidence_OS_VIS_03H_Test_Hotfix_01_$Timestamp"
New-Item -ItemType Directory -Force -Path $Rollback,$Evidence | Out-Null
$Backup = Join-Path $Rollback "MWNorwayOpeningStatePreviewPresentationTests.cpp"
Copy-Item -LiteralPath $Target -Destination $Backup -Force
$Pre = (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash

$UnknownReplacement = '    TestTrue(TEXT("Unknown remains blocked without inferred count"), First.UnknownRecords.Contains(TEXT("count not inferred")));'
$IntentionalReplacement = @'
    TestTrue(TEXT("IntentionalEmpty requires explicit Norway marker"), First.IntentionalEmptyRecords.Contains(TEXT("no explicit Norway IntentionalEmpty marker")));
    TestTrue(TEXT("Zero payload counts are not IntentionalEmpty"), First.IntentionalEmptyRecords.Contains(TEXT("zero payload counts are not treated as IntentionalEmpty")));
'@

$Text = [regex]::Replace($Text, $UnknownPattern, $UnknownReplacement)
$Text = [regex]::Replace($Text, $IntentionalPattern, $IntentionalReplacement.TrimEnd())
Set-Content -LiteralPath $Target -Value $Text -Encoding UTF8
$Post = (Get-FileHash -LiteralPath $Target -Algorithm SHA256).Hash

[ordered]@{
    TaskId = 'OS-VIS-03H-TEST-HOTFIX-01'
    Target = $Target
    Backup = $Backup
    PreChangeSHA256 = $Pre
    PostChangeSHA256 = $Post
    StaleAssertionsReplaced = 2
    NewAssertionsAdded = 3
    Correction = 'Align existing ReadOnlySummary test with accepted OS-VIS-03H evidence-based dispositions'
    GameInstanceCreated = $false
    ApplyCalled = $false
    SaveWritten = $false
    RegistryMutated = $false
    RealmPayloadApplied = $false
    TheaterActivated = $false
} | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $Evidence 'OS_VIS_03H_Test_Hotfix_01_Manifest.json') -Encoding UTF8

Write-Host 'OS-VIS-03H test hotfix 01 installed.' -ForegroundColor Green
Write-Host "Rollback: $Rollback"
Write-Host "Evidence: $Evidence"
Write-Host 'Replaced stale assertions: 2'
Write-Host 'Added current disposition assertions: 3'
