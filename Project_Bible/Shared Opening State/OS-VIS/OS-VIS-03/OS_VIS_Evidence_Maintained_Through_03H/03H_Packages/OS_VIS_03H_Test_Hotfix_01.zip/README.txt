OS-VIS-03H Test Hotfix 01

The build succeeded, and the new RemainingDiagnosticDispositions test passed. The preview parent had one failure because the older ReadOnlySummary test still expected UnknownRecords and IntentionalEmptyRecords to equal "Unavailable from verified read-only API".

This hotfix updates only MWNorwayOpeningStatePreviewPresentationTests.cpp:
- Unknown now asserts the accepted "count not inferred" disposition.
- IntentionalEmpty now asserts the explicit-marker requirement.
- IntentionalEmpty also asserts zero payload counts are not converted to IntentionalEmpty.

Run with Unreal Editor closed:

Set-ExecutionPolicy -Scope Process Bypass
.\Install_OS_VIS_03H_Test_Hotfix_01.ps1

Then build directly:

& "C:\Program Files\Epic Games\UE_5.8\Engine\Build\BatchFiles\Build.bat" MedievalWarEditor Win64 Development -Project="C:\UnrealProjects\MedievalWar\MedievalWar.uproject" -WaitMutex -NoHotReloadFromIDE -NoUBTMakefiles

Then rerun MedievalWar.OpeningState.Preview. Expected: 8 tests, 0 failures, 0 skips, unless additional tests exist locally.
