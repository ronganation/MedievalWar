# MWSharedImporter UE5 Plugin Package

## Status

- Classification: Implement and Validate
- Design status: Static-Checked
- UnrealHeaderTool: Not executed
- UnrealBuildTool: Not executed
- Compile-Validated: No
- Runtime-Validated: No

This is a module-ready editor plugin package for the shared Medieval War manifest preflight. It validates source data and does not create assets, campaign objects, or saves.

## Install

1. Copy `MWSharedImporter` into the target project's `Plugins` directory.
2. Regenerate project files.
3. Build the editor target.
4. Enable the plugin if Unreal does not enable it automatically.

## Commandlet

```text
UnrealEditor-Cmd.exe Project.uproject -run=MWSharedImporterPreflight -unattended -nop4 -nosplash \
  -Manifest="<PluginDir>/MWSharedImporter/Norway_Importer_Source_Manifest_1062.json" \
  -Bindings="<PluginDir>/MWSharedImporter/Shared_Importer_Record_Bindings_v1.json" \
  -Report="<ProjectSavedDir>/Validation/Norway_UE5_Preflight_Report.json"
```

Expected source-level acceptance target:

- status: `PASS_UE5_COMMANDLET_PREFLIGHT`
- records: 88
- direct aliases: 18
- quarantines: 6
- fatal errors: 0
- runtime state created: false

## Ownership

The plugin validates owner routing. It does not become the owner of characters, titles, offices, institutions, claims, succession, governance, relationships, Historical Memory, Historical Momentum, or AI state.

## Integration Notes

- Module export macro is `MWSHAREDIMPORTER_API`.
- `StructUtils` is required for `FInstancedStruct`.
- The plugin is editor-only because the commandlet is a validation tool.
- Payload binding uses `UScriptStruct` pointers and `FInstancedStruct` transport records.
- Preflight commit remains prohibited.
