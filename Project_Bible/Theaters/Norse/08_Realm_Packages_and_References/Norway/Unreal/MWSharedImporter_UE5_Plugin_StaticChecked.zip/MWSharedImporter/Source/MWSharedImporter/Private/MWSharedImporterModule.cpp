#include "MWSharedImporterModule.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_MODULE(FMWSharedImporterModule, MWSharedImporter)

void FMWSharedImporterModule::StartupModule()
{
}

void FMWSharedImporterModule::ShutdownModule()
{
}
