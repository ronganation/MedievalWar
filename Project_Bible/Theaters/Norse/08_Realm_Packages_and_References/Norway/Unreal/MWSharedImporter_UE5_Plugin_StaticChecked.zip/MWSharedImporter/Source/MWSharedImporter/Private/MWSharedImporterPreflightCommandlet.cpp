#include "MWSharedImporterPreflightCommandlet.h"

#include "Dom/JsonObject.h"
#include "HAL/FileManager.h"
#include "Misc/FileHelper.h"
#include "Misc/Parse.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"

DEFINE_LOG_CATEGORY_STATIC(LogMWSharedImporter, Log, All);

namespace MWPreflight
{
    static bool LoadJsonObject(const FString& Path, TSharedPtr<FJsonObject>& OutObject, FString& OutError)
    {
        FString Text;
        if (!FFileHelper::LoadFileToString(Text, *Path))
        {
            OutError = FString::Printf(TEXT("Cannot read JSON file: %s"), *Path);
            return false;
        }

        const TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Text);
        if (!FJsonSerializer::Deserialize(Reader, OutObject) || !OutObject.IsValid())
        {
            OutError = FString::Printf(TEXT("Invalid JSON object: %s"), *Path);
            return false;
        }
        return true;
    }

    static bool IsCanonicalIdValid(const FString& Id)
    {
        TArray<FString> Segments;
        Id.ParseIntoArray(Segments, TEXT("."), false);
        if (Segments.Num() < 2 || Segments[0].IsEmpty() || !FChar::IsAlpha(Segments[0][0]))
        {
            return false;
        }
        for (const FString& Segment : Segments)
        {
            if (Segment.IsEmpty()) return false;
            for (const TCHAR Character : Segment)
            {
                if (!FChar::IsAlnum(Character)) return false;
            }
        }
        return true;
    }

    static void AddError(TArray<TSharedPtr<FJsonValue>>& Errors, const FString& Code, const FString& Detail)
    {
        TSharedRef<FJsonObject> Item = MakeShared<FJsonObject>();
        Item->SetStringField(TEXT("code"), Code);
        Item->SetStringField(TEXT("detail"), Detail);
        Errors.Add(MakeShared<FJsonValueObject>(Item));
    }
}

UMWSharedImporterPreflightCommandlet::UMWSharedImporterPreflightCommandlet()
{
    IsClient = false;
    IsEditor = true;
    IsServer = false;
    LogToConsole = true;
    ShowErrorCount = true;
}

int32 UMWSharedImporterPreflightCommandlet::Main(const FString& Params)
{
    FString ManifestPath;
    FString BindingsPath;
    FString ReportPath;
    FParse::Value(*Params, TEXT("Manifest="), ManifestPath);
    FParse::Value(*Params, TEXT("Bindings="), BindingsPath);
    FParse::Value(*Params, TEXT("Report="), ReportPath);

    TArray<TSharedPtr<FJsonValue>> Errors;
    TArray<TSharedPtr<FJsonValue>> Quarantines;
    TSharedPtr<FJsonObject> Manifest;
    TSharedPtr<FJsonObject> Bindings;
    FString LoadError;

    if (ManifestPath.IsEmpty() || BindingsPath.IsEmpty() || ReportPath.IsEmpty())
    {
        MWPreflight::AddError(Errors, TEXT("MISSING_PARAMETER"), TEXT("Manifest, Bindings, and Report are required."));
    }
    else
    {
        if (!MWPreflight::LoadJsonObject(ManifestPath, Manifest, LoadError))
        {
            MWPreflight::AddError(Errors, TEXT("MANIFEST_LOAD_FAILED"), LoadError);
        }
        if (!MWPreflight::LoadJsonObject(BindingsPath, Bindings, LoadError))
        {
            MWPreflight::AddError(Errors, TEXT("BINDINGS_LOAD_FAILED"), LoadError);
        }
    }

    int32 RecordCount = 0;
    int32 AliasCount = 0;
    if (Manifest.IsValid() && Bindings.IsValid())
    {
        if (Manifest->GetBoolField(TEXT("runtime_creation_permitted")))
        {
            MWPreflight::AddError(Errors, TEXT("RUNTIME_CREATION_NOT_DISABLED"), TEXT("Preflight cannot permit runtime creation."));
        }

        const TSharedPtr<FJsonObject>* BindingMap = nullptr;
        if (!Bindings->TryGetObjectField(TEXT("bindings"), BindingMap) || !BindingMap || !BindingMap->IsValid())
        {
            MWPreflight::AddError(Errors, TEXT("BINDING_MAP_MISSING"), TEXT("Bindings JSON has no bindings object."));
        }

        const TArray<TSharedPtr<FJsonValue>>* Records = nullptr;
        if (!Manifest->TryGetArrayField(TEXT("records"), Records) || !Records)
        {
            MWPreflight::AddError(Errors, TEXT("RECORDS_MISSING"), TEXT("Manifest has no records array."));
        }
        else
        {
            RecordCount = Records->Num();
            TSet<FString> CanonicalIds;
            FString PreviousSortKey;
            for (const TSharedPtr<FJsonValue>& Value : *Records)
            {
                const TSharedPtr<FJsonObject> Record = Value.IsValid() ? Value->AsObject() : nullptr;
                if (!Record.IsValid())
                {
                    MWPreflight::AddError(Errors, TEXT("INVALID_RECORD"), TEXT("Record is not a JSON object."));
                    continue;
                }
                const FString Type = Record->GetStringField(TEXT("record_type"));
                const FString Id = Record->GetStringField(TEXT("canonical_id"));
                const FString Owner = Record->GetStringField(TEXT("owner"));
                if (!MWPreflight::IsCanonicalIdValid(Id))
                {
                    MWPreflight::AddError(Errors, TEXT("INVALID_CANONICAL_ID"), Id);
                }
                if (CanonicalIds.Contains(Id))
                {
                    MWPreflight::AddError(Errors, TEXT("DUPLICATE_CANONICAL_ID"), Id);
                }
                CanonicalIds.Add(Id);

                if (BindingMap && BindingMap->IsValid())
                {
                    const TSharedPtr<FJsonObject>* Rule = nullptr;
                    if (!(*BindingMap)->TryGetObjectField(Type, Rule) || !Rule || !Rule->IsValid())
                    {
                        MWPreflight::AddError(Errors, TEXT("UNBOUND_RECORD_TYPE"), Type);
                    }
                    else if ((*Rule)->GetStringField(TEXT("owner")) != Owner)
                    {
                        MWPreflight::AddError(Errors, TEXT("OWNER_MISMATCH"), Id);
                    }
                }

                const FString SortKey = Type + TEXT("\n") + Id;
                if (!PreviousSortKey.IsEmpty() && SortKey < PreviousSortKey)
                {
                    MWPreflight::AddError(Errors, TEXT("NONDETERMINISTIC_RECORD_ORDER"), Id);
                }
                PreviousSortKey = SortKey;
            }

            for (const TSharedPtr<FJsonValue>& Value : *Records)
            {
                const TSharedPtr<FJsonObject> Record = Value->AsObject();
                if (!Record.IsValid()) continue;
                const TArray<TSharedPtr<FJsonValue>>* References = nullptr;
                if (Record->TryGetArrayField(TEXT("references"), References) && References)
                {
                    for (const TSharedPtr<FJsonValue>& Ref : *References)
                    {
                        const FString RefId = Ref->AsString();
                        if (!CanonicalIds.Contains(RefId))
                        {
                            MWPreflight::AddError(Errors, TEXT("UNRESOLVED_REFERENCE"), RefId);
                        }
                    }
                }
            }
        }

        const TArray<TSharedPtr<FJsonValue>>* Aliases = nullptr;
        if (Manifest->TryGetArrayField(TEXT("direct_aliases"), Aliases) && Aliases)
        {
            AliasCount = Aliases->Num();
            TSet<FString> DeprecatedIds;
            for (const TSharedPtr<FJsonValue>& Value : *Aliases)
            {
                const TSharedPtr<FJsonObject> Alias = Value->AsObject();
                if (Alias.IsValid()) DeprecatedIds.Add(Alias->GetStringField(TEXT("deprecated_id")));
            }
            for (const TSharedPtr<FJsonValue>& Value : *Aliases)
            {
                const TSharedPtr<FJsonObject> Alias = Value->AsObject();
                if (!Alias.IsValid()) continue;
                const FString Deprecated = Alias->GetStringField(TEXT("deprecated_id"));
                const FString Canonical = Alias->GetStringField(TEXT("canonical_id"));
                if (Deprecated == Canonical) MWPreflight::AddError(Errors, TEXT("SELF_ALIAS"), Deprecated);
                if (DeprecatedIds.Contains(Canonical)) MWPreflight::AddError(Errors, TEXT("ALIAS_CHAIN"), Canonical);
            }
        }

        const TArray<TSharedPtr<FJsonValue>>* Contextual = nullptr;
        if (Manifest->TryGetArrayField(TEXT("context_sensitive_migrations"), Contextual) && Contextual)
        {
            for (const TSharedPtr<FJsonValue>& Value : *Contextual)
            {
                const TSharedPtr<FJsonObject> Source = Value->AsObject();
                if (!Source.IsValid()) continue;
                TSharedRef<FJsonObject> Item = MakeShared<FJsonObject>();
                Item->SetStringField(TEXT("id"), Source->GetStringField(TEXT("deprecated_id")));
                Item->SetStringField(TEXT("disposition"), Source->GetStringField(TEXT("disposition")));
                Item->SetBoolField(TEXT("runtime_state_created"), false);
                Quarantines.Add(MakeShared<FJsonValueObject>(Item));
            }
        }
    }

    TSharedRef<FJsonObject> Report = MakeShared<FJsonObject>();
    Report->SetStringField(TEXT("status"), Errors.IsEmpty() ? TEXT("PASS_UE5_COMMANDLET_PREFLIGHT") : TEXT("FAIL_UE5_COMMANDLET_PREFLIGHT"));
    Report->SetBoolField(TEXT("runtime_state_created"), false);
    Report->SetNumberField(TEXT("record_count"), RecordCount);
    Report->SetNumberField(TEXT("direct_alias_count"), AliasCount);
    Report->SetNumberField(TEXT("quarantine_count"), Quarantines.Num());
    Report->SetNumberField(TEXT("fatal_error_count"), Errors.Num());
    Report->SetArrayField(TEXT("fatal_errors"), Errors);
    Report->SetArrayField(TEXT("quarantines"), Quarantines);

    FString Output;
    const TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&Output);
    FJsonSerializer::Serialize(Report, Writer);
    FFileHelper::SaveStringToFile(Output, *ReportPath);

    UE_LOG(LogMWSharedImporter, Display, TEXT("%s: records=%d errors=%d quarantines=%d"),
        Errors.IsEmpty() ? TEXT("PASS_UE5_COMMANDLET_PREFLIGHT") : TEXT("FAIL_UE5_COMMANDLET_PREFLIGHT"),
        RecordCount, Errors.Num(), Quarantines.Num());

    return Errors.IsEmpty() ? 0 : 2;
}
