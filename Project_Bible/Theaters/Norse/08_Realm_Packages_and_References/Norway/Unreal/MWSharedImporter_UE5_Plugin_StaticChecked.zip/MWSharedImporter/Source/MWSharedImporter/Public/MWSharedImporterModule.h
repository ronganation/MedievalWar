#pragma once

#include "Modules/ModuleManager.h"

class FMWSharedImporterModule final : public IModuleInterface
{
public:
    virtual void StartupModule() override;
    virtual void ShutdownModule() override;
};
