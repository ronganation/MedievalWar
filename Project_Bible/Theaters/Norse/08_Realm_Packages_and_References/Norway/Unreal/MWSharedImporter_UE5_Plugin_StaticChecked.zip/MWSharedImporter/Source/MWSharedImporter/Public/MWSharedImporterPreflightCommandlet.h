#pragma once

#include "CoreMinimal.h"
#include "Commandlets/Commandlet.h"
#include "MWSharedImporterPreflightCommandlet.generated.h"

/**
 * Shared, realm-neutral JSON manifest preflight.
 * It validates only and never creates assets, campaign objects, or saves.
 * Usage:
 * UnrealEditor-Cmd.exe Project.uproject -run=MWSharedImporterPreflight
 *   -Manifest=".../Norway_Importer_Source_Manifest_1062.json"
 *   -Bindings=".../Shared_Importer_Record_Bindings_v1.json"
 *   -Report=".../Norway_UE5_Preflight_Report.json"
 */
UCLASS()
class MWSHAREDIMPORTER_API UMWSharedImporterPreflightCommandlet final : public UCommandlet
{
    GENERATED_BODY()

public:
    UMWSharedImporterPreflightCommandlet();
    virtual int32 Main(const FString& Params) override;
};
